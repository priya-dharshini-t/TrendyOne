<!DOCTYPE html>
<html>
<head>
  <title>Fashion Store</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="landing">
  <div class="center-box">
    <img src="assets/logo.png" alt="Logo" class="logo">
    <h1>🛍️ Welcome to Fashion Store</h1>
    <a href="login.php" class="btn">Get Started</a>
  </div>
</body>
</html>
