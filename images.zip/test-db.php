<?php
include "config.php";
echo "Connected to database!";
?>
